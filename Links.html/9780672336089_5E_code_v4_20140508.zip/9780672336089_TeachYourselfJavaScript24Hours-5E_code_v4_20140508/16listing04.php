<?php 
header('Content-Type: text/xml');
echo "<?xml version=\"1.0\" ?><greeting>Hello Ajax caller!</greeting>”;
?>
