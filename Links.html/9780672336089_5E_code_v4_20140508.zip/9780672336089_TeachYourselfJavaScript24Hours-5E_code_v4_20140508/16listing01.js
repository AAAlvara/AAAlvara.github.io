function getXMLHttpRequest() {
	try {
		try {
			return new ActiveXObject("Microsoft.XMLHTTP");
		}
		catch(e) {
			return new ActiveXObject("Msxml2.XMLHTTP");
		}
	}
	catch(e) {
		return new XMLHttpRequest();
	}
}
